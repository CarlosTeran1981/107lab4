
var http = require("http");

var express = require("express"); // require express
var app = express ();

// Configuration
// Enable CORS
app.use(function (req, res, next){

  res.header("Access-Control-Allow-Origin", "*");

  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE, PATCH");

  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

  next();

});

// read req body as obj
var bparser = require("body-parser");
app.use(bparser.json());

app.use(express.static(__dirname + '/views'));

var ejs = require('ejs');
app.set('views', __dirname + '/views');
app.engine('html', ejs.renderFile);
app.set('view engine', ejs);

console.log( __dirname + '/views');




var mongoose = require('mongoose');
mongoose.connect('mongodb://ThiIsAPassword:TheRealPassword@cluster0-shard-00-00-euadh.mongodb.net:27017,cluster0-shard-00-01-euadh.mongodb.net:27017,cluster0-shard-00-02-euadh.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin'
);

var db = mongoose.connection;

// DB objet constructor
var ItemDB;

/*************************************************** */
/*****************************************************
 *          Storage option
 * ************************************************/

 var items = [];
 var nextId = 0;



var app = express(); //create an express app

app.get('/', (req, res) => {
  res.render("index.html");
});

app.get('/contact', (req, res) => {
   });

app.get('/about', (req, res) => {
    res.send("about.html");  
  });

app.get('/admin', (req, res) => {
  res.render("admin.html");
});

app.get('/api/products', (req, res) => {
    res.json(items);
});

app.post('/api/products', (req, res) => {
  
  ItemDB.find({}, function(error, data){
    if(error){
      console.log("Error reading data", error);
      res.status(500);
      res.send(error);
    }

    res.json(data);
  }); 

});

app.get("/api/products/:user", (req, res) =>{

  ItemDB.find({stock : {$gte: 0}}, function(error, data){
    if(error){
      console.log("Error reading data", error);
      res.status(500);
      res.send(error);
    }

    res.json(data);
  }); 
})


  app.post("/api/products", (req, res) => {
  var itemToSave = new ItemDB(req.body);

  item.save(function (error, saveItem){

      if(error){
          console.log("Error, item was not saved to Mongo", error);
          res.status(500);
          res.send(error);
      }
        console.log("Item saved correctly!!!");

  res.status = 201;
  res.json(saveItem);
});

});

db.on('error', function (error) {
  console.log("Error connection to Mongo server", error);
});

db.on('open', function (){
  console.log("Yeiii DB its ALIVE");


var itemSchema = mongoose.Schema({
    title: String,
    description: String,
    price: Number,
    image: String,
    category: String,
    user: String
});

ItemDB = mongoose.model("itemCh4", itemSchema);

});




app.listen(8080, () => {
  console.log('Server running at http://localhost:8080');
});

